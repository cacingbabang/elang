<?php

include "../config.php";
session_start();
$id = $_GET["id_menu"];
if($_SESSION["admin"] == "" )
{
    echo "
    <script>
        alert('harap login terlebih dahulu')
        document.location.href = '../auth/login.php'
    </script>
    ";
}

function delete($id)
{
    global $connection;
    mysqli_query($connection,"DELETE FROM tb_menu WHERE id_menu = $id ");
    return mysqli_affected_rows($connection);
}

if(delete($id) > 0){
    echo"
    <script>
        document.location.href = './index.php'
    </script>";
    
}
?>