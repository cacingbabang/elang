<?php

include "../config.php";
session_start();
if($_SESSION["admin"] == "" )
{
    echo "
    <script>
        alert('harap login terlebih dahulu')
        document.location.href = '../auth/login.php'
    </script>
    ";
}

function imageMenu(){

    $nameFile = $_FILES["image_menu"]["name"];
    $tempName = $_FILES["image_menu"]["tmp_name"];
    $error = $_FILES["image_menu"]["error"];

    // check if no images are uploaded
    if( $error === 4 ){
        echo "please upload image!";
    }

    // check extension image
    $extension = ["jpg","png","jpeg","jfif"];
    $extensionImage = explode(".",$nameFile);
    $extensionImage = strtolower(end($extensionImage));
    
    
    if( !in_array($extensionImage,$extension) ){
        echo "this file not image";
    }
    
    // change name image from default to random string
    $newName = uniqid();
    $newName .= ".";
    $newName .= $extensionImage;
    
    move_uploaded_file($tempName, '../img/menu/' . $newName);

    return $newName;

}

function create($data)
{
    global $connection;
    // menu,price,image
    $name = $data["name_menu"];
    $price = $data["price_menu"];
    $image = imageMenu();
    if(!imageMenu()){return false;}

    mysqli_query($connection,"INSERT INTO tb_menu VALUES
        (
            '',
            '$name',
            '$price',
            '$image'
        )"
    );

    return mysqli_affected_rows($connection);
}

if(isset($_POST["submit"]))
{
    // var_dump($_POST,$_FILES);
    // die;
    if(create($_POST) > 0)
    {
        echo "
        <script>
            document.location.href = 'index.php'
        </script>
        ";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body id="bg-update">
<header>
    <div class="container">
    <h1><a href='../admin/index.php'>Dashboard</a></h1>
            <ul>
                <li><a href="../menu/index.php">Menu</a></li>
                <li><a href="../admin/user/index.php">User</a></li>
                <li><a href="../auth/logout.php">Keluar</a></li>
            </ul>
        </div>
</header>
 <div class="section">
 <div class="box-menu">
    <form action="" method="post" enctype="multipart/form-data">
    <h3 class="ubah-password">Create Menu</h3>
        <input type="text" name="name_menu" id="" placeholder="name menu" class="input-control"><br>
        <input type="number" name="price_menu" id="" placeholder="price menu" class="input-control"><br>
        <input type="file" name="image_menu" id="" class="file" ><br>
        <button type="submit" name="submit">submit</button>
    </form>
</div>
</div>
</body>
</html>