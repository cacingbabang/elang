<?php

include ("./../config.php");
session_start();
if($_SESSION["user"] == "" )
{
    echo "
    <script>
        alert('harap login terlebih dahulu')
        document.location.href = '../auth/login.php'
    </script>
    ";
}

$menus = mysqli_query($connection,"SELECT * FROM tb_menu");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body id="bg-menu" >
    <header>
    <div class="container">
    <h1><a href='index.php'>Dashboard</a></h1>
            <ul>
                <li><a href="index.php">Menu</a></li>
                <li><a href="../auth/logout.php">Keluar</a></li>
            </ul>
        </div>
    </header>
    <div class="section">
        <div class="container">
        
          <h3 class="ubah-password" margin-bottom="10px" >Menu</h3>
            <br>
                <?php while($row = mysqli_fetch_assoc($menus)) : ?>
                    <div class="col-4">

                        <img src="../img/menu/<?= $row["image_menu"] ?>" class="border" height="190" >
                         <p class="nama"><?= $row["name_menu"] ?></p>
                        <p class="harga">Rp<?= $row["price_menu"] ?></p>
                        <br><br><br><br>

                        
                    </div>
                <?php endwhile ?>
                
            </div>
        </div>
    </div>
</body>
</html>