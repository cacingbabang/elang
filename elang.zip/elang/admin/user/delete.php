<?php

include "../../config.php";
session_start();
$id = $_GET["id_user"];
if($_SESSION["admin"] == "" )
{
    echo "
    <script>
        alert('harap login terlebih dahulu')
        document.location.href = '../auth/login.php'
    </script>
    ";
}

mysqli_query($connection,"DELETE FROM tb_user WHERE id_user = $id ");

echo'
    <script>
        document.location.href = "index.php"
    </script>';

?>