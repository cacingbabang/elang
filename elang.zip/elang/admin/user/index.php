<?php

include "../../config.php";
session_start();
if($_SESSION["admin"] == "" )
{
    echo "
    <script>
        alert('harap login terlebih dahulu')
        document.location.href = '../../auth/login.php'
    </script>
    ";
}

$users = mysqli_query($connection,"SELECT * FROM tb_user ORDER BY id_user ASC");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="../../css/style.css">
</head>
<body id="bg-admin">
<header>
    <div class="container">
    <h1><a href='../index.php'>Dashboard</a></h1>
            <ul>
                <li><a href="../../menu/index.php">Menu</a></li>
                <li><a href="../../admin/user/index.php">User</a></li>
                <li><a href="../auth/logout.php">Keluar</a></li>
            </ul>
        </div>
    </header>
    <div class="section">
        <div class="container">
                <h3 class="ubah-password">Ubah Profil</h3>
                <?php while($user = mysqli_fetch_assoc($users)) : ?>
                    <div class="admin-box">
                        <div class="col-5">
                            <p class="username"> status: <?= $user["level"] ?></p>
                            <p class="username">Username: <?= $user["username"] ?>  </p>
                            <p class="username">Password: <?= $user["password"] ?></p>
                            <br>
                            <p class="edit-delete">
                                <a href="update.php?id_user=<?= $user["id_user"] ?>">Edit</a>
                                <a href="delete.php?id_user=<?= $user["id_user"] ?>">delete</a>
                            </p>
                            <br>
                        </div>
                    </div>
                <?php endwhile?>     
        </div>    
    </div>        
    
</body>
</html>