<?php

include "../config.php";
session_start();
if($_SESSION["admin"] == "" )
{
    echo "
    <script>
        alert('harap login terlebih dahulu')
        document.location.href = '../../auth/login.php'
    </script>
    ";
}

$users = mysqli_query($connection,"SELECT * FROM tb_user");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body id="bg-admin">
<header>
    <div class="container">
    <h1><a href='../admin/index.php'>Dashboard</a></h1>
            <ul>
                <li><a href="../menu/index.php">Menu</a></li>
                <li><a href="../admin/user/index.php">User</a></li>
                <li><a href="../auth/logout.php">Keluar</a></li>
            </ul>
        </div>
    </header>
</html>