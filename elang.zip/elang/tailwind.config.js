/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./admin/*.{html,js,php}",
    "./auth/*.{html,js,php}",
    "./menu/*.{html,js,php}",
    "./user/*.{html,js,php}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
